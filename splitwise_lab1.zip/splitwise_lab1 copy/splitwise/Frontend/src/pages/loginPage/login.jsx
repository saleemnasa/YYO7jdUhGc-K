
import './login.css';
import { Container, Row, Col } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { connect } from 'react-redux'
import useForm from "../../components/Form/useForm";
import validate from './loginRules';
import { loginUserData, setuserdata, logUser } from '../../redux/login';
import { useHistory } from "react-router-dom";
import { logo2 } from '../../constants';

const Login = (props) => {
  const {
    values,
    errors,
    handleChange,
    handleSubmit,
  } = useForm(login, validate);
  const [loginData, setloginData] = useState(true);
  const history = useHistory();
  function login() {
    console.log(values, "values")
    props.setuserdata(values);
    props.logUser()

  }
  useEffect(() => {
    console.log(props.loginDatauser)
    if (Object.keys(props.loginDatauser).length > 0) {
      history.push("/dashboard");
    }

  });

  return (
    <div className="section  elment-center" >
      <Container>
        <Row >
          <Col md={12} className="pt-5 pb-1">
            <div className="registration-block text-center mb-1">
              <img src={logo2} className="logo mb-1" alt="" />

              <h3>Welcome! </h3>
              <p>Do not have an account? <Link to="/signup">Signup</Link></p>
            </div>

          </Col>

          <Col md={12} className="">

            <div className="login-banner d-flex justify-content-center bd-highlight mb-3">

              <form onSubmit={handleSubmit} noValidate className="mt-1 mb-3 pr-3 pl-3 w-25"  >
                <div>
                  <label>Email</label>
                  <div className={errors.email ? "inputError" : ''}>
                    <input
                      name="email"
                      type="email"
                      value={values.email}
                      onChange={handleChange}
                      className="form-control"
                    />
                    {errors.email && <p className="error">{errors.email}</p>}
                  </div>
                </div>
                <div className="mb-3">
                  <label>Password</label>
                  <div className={errors.password ? "inputError" : ''}>
                    <input
                      name="password"
                      type="password"
                      value={values.password}
                      onChange={handleChange}
                      className="form-control"
                    />
                    {errors.password && <p className="error">{errors.password}</p>}
                  </div>
                </div>

                <button type="submit" className="mt-3 btn btn-primary">Submit</button>
              </form>

            </div>
          </Col>

        </Row>

      </Container>

    </div>
  );
};
export default connect(
  (state) => {
    return {
      loginDatauser: state.login.loginData
    }
  },
  {
    loginUserData,
    setuserdata,
    logUser
  }
)(Login);