// import React, { useState } from 'react';
import './signup.css';
import { useState, useEffect } from 'react';

import { Row, Col, Container, Button, Form, FormControl } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import useForm from "../../components/Form/useForm";
import validate from './sinupRules';
import { loginUserData, setuserdata, sinupUser } from '../../redux/login';
import { connect } from 'react-redux'
import { useHistory } from "react-router-dom";
import { logo2 } from '../../constants';

const Signup = (props) => {

  const {
    values,
    errors,
    handleChange,
    handleSubmit,
  } = useForm(login, validate);
  // const [success, setsuccess] = useState(true);
  function login() {

    console.log(values, "Signup")
    props.setuserdata(values);
    props.sinupUser()
  }
  const history = useHistory();
  useEffect(() => {
    console.log(props.loginDatauser)
    if (Object.keys(props.loginDatauser).length > 0) {
      history.push("/dashboard");
    }
  });

  return (
    <div className="section  elment-center" >

      <Container>
        <Row >
          <Col md={12} className="pt-5 pb-1">
            <div className="registration-block text-center mb-1">
              <img src={logo2} className="logo" alt="" />
              <h3>welcome!</h3>
              <p>Have an account?  <Link to="/login">login</Link></p>
            </div>

          </Col>
          <Col md={12} >
            <div className="login-banner d-flex justify-content-center bd-highlight mb-3">
              <Form className="mt-1 mb-3 pr-3 pl-3 w-25" onSubmit={handleSubmit} noValidate>
                <Form.Group>
                  <Form.Label>Name <span className="error">*</span></Form.Label>
                  <FormControl
                    type="text"
                    className={`${errors.name && "inputError"}`}
                    name="firstName"
                    placeholder="user Name "
                    value={values.firstName}
                    onChange={handleChange} />
                </Form.Group>
                {errors.firstName && <p className="error">{errors.firstName}</p>}


                <Form.Group>
                  <Form.Label>Email <span className="error">*</span></Form.Label>
                  <Form.Control
                    type="email"
                    placeholder="Enter email"
                    className={`${errors.email && "inputError"}`}
                    name="email"
                    value={values.email}
                    onChange={handleChange}
                  />
                </Form.Group>
                {errors.email && <p className="error">{errors.email}</p>}

                <Form.Group>
                  <Form.Label>Password <span className="error">*</span></Form.Label>
                  <Form.Control
                    type="password"
                    placeholder="Password"
                    className={`${errors.password && "inputError"}`}
                    name="password"
                    value={values.password}
                    onChange={handleChange}
                  />
                </Form.Group>
                {errors.password && <p className="error">{errors.password}</p>}
                <Button variant="primary" type="submit" block >  Submit   </Button>
              </Form>
            </div>
          </Col>
        </Row>

      </Container>
    </div>

  );
}
export default connect(
  (state) => {
    return {
      loginDatauser: state.login.loginData
    }
  },
  {
    loginUserData,
    setuserdata,
    sinupUser
  }
)(Signup);
