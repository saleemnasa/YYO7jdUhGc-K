import React from 'react';
import styles from './sideBar.css';
import { Nav, NavItem, Navbar, NavDropdown, MenuItem, } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { logo2 } from '../../constants';

const SideBar = props => {


    return (
        <>

            <Nav className="col-md-12 d-none d-md-block bg-light sidebar">
                <div className="sidebar-sticky">
                    <img src={logo2} className="p-2"></img>
                </div>
                <Nav.Item >
                    <Link className="nav-link" style={{ color: ' rgb(94, 190, 163)' }} to={"/dashboard"} >    Dashboard</Link>
                </Nav.Item>
                <Nav.Item >
                    <Link className="nav-link" style={{ color: ' rgb(94, 190, 163)' }} to={"/profile"}>Profile </Link>
                </Nav.Item>
                <Nav.Item >
                    <Link className="nav-link" style={{ color: ' rgb(94, 190, 163)' }} to={"/creategroup"} >Create new group</Link>
                </Nav.Item>

                <Nav.Item >
                    <Link className="nav-link" style={{ color: ' rgb(94, 190, 163)' }} to={"/my-groups"}>My Groups</Link>
                </Nav.Item>

                <Nav.Item >
                    <Link className="nav-link" style={{ color: ' rgb(94, 190, 163)' }} to={"/recent-activity"} >Recent Activity</Link>
                </Nav.Item>

            </Nav>

        </>
    );
};
export default SideBar;