import useForm1 from "./Form/useForm";
import { Container, Row, Col, Form, Button } from 'react-bootstrap';
import { useForm } from 'react-hook-form';
import React, { useRef, useState, useEffect, forwardRef } from 'react';
const Select = React.forwardRef((props, ref) => (
    ({ options, ...props }, ref) => (
        <select ref={ref} {...props}>
            {options.map(({ label, value }) => (
                <option value={value}>{label}</option>
            ))}
        </select>

    )))
const UserForm = (props) => {
    const { register, handleSubmit, errors } = useForm(); // initialize the hook
    const onSubmit = (data) => {
        console.log(data);
    };
    const [user, setisMobile] = useState(props.user);

    const Select = React.forwardRef((props, ref) => (
        ({ options, ...props }, ref) => (
            <select ref={ref} {...props}>
                {options.map(({ label, value }) => (
                    <option value={value}>{label}</option>
                ))}
            </select>
        )
    ));
    return (
        <>
            <form onSubmit={handleSubmit(onSubmit)}>

                <Row>
                    <Col md={8}>
                        <Row>
                            <Col md={5}>
                                <div className="profile-img" style={{ backgroundImage: `url(${'./user.jpg'})` }}></div>

                                <Form.File id="formcheck-api-regular">
                                    <Form.File.Label>Change your avatar</Form.File.Label>
                                    <Form.File.Input />
                                </Form.File>
                            </Col>
                            <Col md={7}>


                                <div className="form-group">
                                    <label>your name</label>

                                    <input name="firstName" ref={register({ required: true })} defaultValue={user.firstName} className="form-control" />
                                    {errors.firstName && 'First name is required.'}
                                </div>
                                <div className="form-group">
                                    <label>your email address</label>
                                    <input
                                        name="email"
                                        type="email"
                                        defaultValue={user.email}
                                        ref={register({ required: true })}
                                        className="form-control"
                                    />
                                    {errors.email && <p className="error">{errors.email}</p>}
                                </div>
                                <div className="form-group">
                                    <label>your phone number</label>
                                    <input
                                        name="phone"
                                        type="text"
                                        defaultValue={user.phone}
                                        ref={register({ required: true })}
                                        className="form-control"
                                    />
                                    {errors.phone && <p className="error">{errors.phone}</p>}

                                </div>


                            </Col>

                        </Row>
                    </Col>
                    <Col md={4}>

                        <div className="form-group">
                            <label>your default currency</label>
                            <Select
                                name="currency"
                                defaultValue={user.currency}
                                ref={register}
                                className="form-control"
                                options={[
                                    { label: "Female", value: "female" },
                                    { label: "Male", value: "male" },
                                    { label: "Other", value: "other" }
                                ]}
                            />

                            {errors.currency && <p className="error">{errors.currency}</p>}

                        </div>

                        <Form.Group>
                            <Form.Label>your time zone</Form.Label>
                            <Form.Control size="sm" type="text" placeholder="Small text" defaultValue={new Date()} />
                        </Form.Group>
                        <Form.Group controlId="exampleForm.ControlSelect1">
                            <Form.Label> language </Form.Label>
                            <Form.Control name="language" as="select" >
                                <option>English</option>
                                <option>Spanish</option>
                                <option>Japanese</option>

                            </Form.Control>
                        </Form.Group>

                    </Col>


                </Row>

                <input name="firstName" /> {/* register an input */}
                {errors.firstName && 'First name is required.'}
                <input name="lastname" ref={register({ required: true })} />
                {errors.lastname && 'Last name is required.'}
                <input name="age" ref={register({ pattern: /\d+/ })} />
                {errors.age && 'Please enter number for age.'}
                <input type="submit" />
            </form>
        </>
    )
}
export default UserForm;
