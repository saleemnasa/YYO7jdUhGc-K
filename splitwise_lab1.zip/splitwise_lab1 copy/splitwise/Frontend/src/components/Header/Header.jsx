import React from 'react';
// import PropTypes from 'prop-types';
import { logo } from '../../constants';
import './Header.css';
import { Button, Form, Nav, Navbar, InputGroup, FormControl, DropdownButton, Dropdown } from 'react-bootstrap';
import { Container, Col, Row } from 'react-bootstrap';
import { BrowserRouter as Router, Route, Switch, Link, useLocation } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { connect } from 'react-redux'
import { loginUserData } from '../../redux/login';

const Header = (props) => {
  // $("#").toggleClass("collapsed");

  const [state, setState] = useState(true);
  const [curentuser, cccccccc] = useState(props.userData);


  function toggle() {
    setState(!state);
  }
  function togglebind() {
    setState(true);
  }
  const location = useLocation();

  React.useEffect(() => {
    togglebind();
  }, [location]);


  useEffect(() => {
    props.loginUserData();
    // console.log(props.loginDatauser, "props.loginDatauser")
    console.log(props.loginDatauser, "props.loginDatauser")
    console.log(Object.keys(props.loginDatauser).length > 0, "data")
    if (Object.keys(props.loginDatauser).length > 0) {
      // history.push("/");
      setcurentuser(props.loginDatauser)
    }

  }, [props.loginDatauser]);
  const logout = () => {
    localStorage.removeItem("loginUser")
    localStorage.removeItem("Usertoken")
    window.location.reload(false)
    console.log('reload')
  };

  return (
    <header className="header--section">
      <Container>

        <Row className="mt-2 mb-2">
          <Col xs={4} md={3} >
            <a to="/"><img src={logo} className="logo" alt="" /></a>


          </Col>
          <Col xs={8} md={9} >
            <div className="nav float-right pt-3">
              <div id="searchbar" className={state ? 'collapsed' : ''} >
                <div id="search-box">
                  <div id="sliding-panel-outer">
                    <div id="sliding-panel-inner">
                      <InputGroup className=" searchon">
                        <FormControl aria-describedby="basic-addon1" type="text" />

                        <InputGroup.Prepend>
                          <Button variant="outline-secondary">
                            <i className="fa fa-search"></i>
                          </Button>
                        </InputGroup.Prepend>
                      </InputGroup>
                    </div>
                  </div>

                  <div className="search-label pt-2">
                    {/* <div className="search-label pt-2" style={{ background: 'url(../images/list-i.png) no-repeat right',backgroundPosition: '95% 50%', height: '48px'}}> */}

                     Search&nbsp;
                      <i className="fa fa-search" onClick={toggle}></i>
                    <i className="fa fa-times" onClick={toggle}></i>
                  </div>
                </div>
                {/* {state ? <span>Yes! 👍</span> : <span>No! 👎</span>} */}
              </div>

              {curentuser ?

                <div><DropdownButton
                  menuAlign="right"
                  title={curentuser.firstName || ""}
                  id="dropdown-menu-align-right"
                >
                  <Dropdown.Item eventKey="1">Action</Dropdown.Item>
                  <Dropdown.Item eventKey="2">Another action</Dropdown.Item>
                  <Dropdown.Item eventKey="3">Something else here</Dropdown.Item>
                  <Dropdown.Item eventKey="4">Separated link</Dropdown.Item>
                </DropdownButton></div> :
                <div className="pt-2"><Link to="/login" style={{ color: "var(--text-brand-color)" }} onClick={logout}>Login <i className="fa fa-user" aria-hidden="true"></i></Link></div>


              }

            </div>
          </Col>
          {/* jaisurya */}
        </Row>


      </Container>
      <Navbar expand="lg" className="mainnavbar">
        <Container>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="navbar-nav ml-auto float-right" >
              <Link to="/">Home</Link>
              <Link to="About">About</Link>
              <Link to="our-team">Our Team</Link>

              {/* <NavDropdown title="Guidelines" id="basic-nav-dropdown" >
              <Link to="/editor-guidelines">Editor Guidelines</Link>
              <Link to="/reviewer-guidelines">Reviewer Guidelines</Link>
              <Link to="/author-guidelines">Author Guidelines</Link>
              <Link to="/manuscript-guidelines">Manuscript Guidelines</Link>
            </NavDropdown> */}
              <Link to="guidelines" >Guidelines</Link>
              <Link to="contact-us" >Contact Us</Link>

            </Nav>

          </Navbar.Collapse>
        </Container>
      </Navbar>

    </header>
  );

}

export default connect(
  (state) => {
    return {
      userData: state.login.loginData
    }
  },
  {
    // logUser,
    // setuserdata
    loginUserData

  }
)(Header);;

// loginData