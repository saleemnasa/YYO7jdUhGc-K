
import React from "react";

function message({ values, errors, touched }) {
  return (
    <div>
      <code> <pre>Values: {JSON.stringify(values)}</pre></code>
      <br />
      <code>Errors: {JSON.stringify(errors)}</code>
      <br />
      <code>Touched: {JSON.stringify(touched)}</code>
      <br />
    </div>
  );
}

export default message;