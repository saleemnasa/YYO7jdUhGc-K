import { useState, useEffect } from 'react';

const useForm1 = (callback, validate) => {

  const [values, setValues] = useState({});
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (Object.keys(errors).length === 0 && isSubmitting) {
      callback();
    }
  }, [errors]);

  const handleSubmit = (event) => {
    console.log(values)
    if (event) event.preventDefault();
    setErrors(validate(values));
    setIsSubmitting(true);
  };

  const handleChange = (event) => {
    console.log(event)
    // var userObject = JSON.parse(localStorage.getItem("loginUser")) || {};
    if (event.target) {
      setValues(values => ({ ...values, [event.target.name]: event.target.value }));
    } else {
      setValues(values => ({ ...values, [event.name]: event.value }));
    }


  };


  return {
    handleChange,
    handleSubmit,
    values,
    errors,
  }
};

export default useForm1;