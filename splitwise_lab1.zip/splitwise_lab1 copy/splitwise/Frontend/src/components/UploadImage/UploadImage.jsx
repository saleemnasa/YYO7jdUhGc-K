import React from 'react'
// const axios = require("axios");
import { BASEURL } from '../../constants'

import axios from 'axios';
class ReactUploadImage extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            file: null
        };
        this.onFormSubmit = this.onFormSubmit.bind(this);
        this.onChange = this.onChange.bind(this);
    }
    onFormSubmit(e) {
        e.preventDefault();
        const formData = new FormData();
        console.log(this.state.file)
        if (this.state.file) {
            formData.append('myImage', this.state.file);
            const config = {
                headers: { 'content-type': 'multipart/form-data' }
            };
            axios.post(BASEURL + "/uploads", formData, config)
                .then((response) => {
                    // alert("The file is successfully uploaded");
                    console.log(response)
                }).catch((error) => {
                });
        }

    }
    onChange(e) {

        this.setState({ file: e.target.files[0] });
        this.props.handleUpload(e.target.files[0]);
    }

    render() {
        return (
            <>
                <form onSubmit={this.onFormSubmit} noValidate>

                    <input type="file" name="myImage" onChange={this.onChange} />
                    {/* <button type="submit">Upload</button> */}
                </form>
            </>
        )
    }
}

export default ReactUploadImage