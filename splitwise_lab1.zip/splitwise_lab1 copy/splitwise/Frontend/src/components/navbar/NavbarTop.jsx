import { Container, Row, Nav, Dropdown, DropdownButton, Button, Navbar } from "react-bootstrap";
import React, { useState, useEffect } from 'react';
import { connect } from 'react-redux'
import { loginUserData, setuserdata, logUser } from '../../redux/login';
const NavbarTop = (props) => {
    const [loginData, setloginData] = useState(JSON.parse(localStorage.getItem("loginUser")) || {});
    useEffect(() => {
        console.log('reload', JSON.parse(localStorage.getItem("loginUser")) || {})


    });
    const logout = () => {
        localStorage.removeItem("loginUser")
        localStorage.removeItem("Usertoken")
        window.location.reload(false)
        console.log('reload')
    };
    return (
        <>
            <Navbar style={{ background: "#5ebea3" }}>
                <Navbar.Brand >
                    < Button variant="light" size="sm" id="menu-toggle" onClick={props.toggled}>

                        <svg viewBox="0 0 100 80" width="15" height="15">
                            <rect width="100" height="10"></rect>
                            <rect y="30" width="100" height="10"></rect>
                            <rect y="60" width="100" height="10"></rect>
                        </svg>
                    </Button></Navbar.Brand>
                <Navbar.Toggle />
                <Navbar.Collapse className="justify-content-end">
                    <Navbar.Text>
                        <Nav className="mr-auto">


                            <DropdownButton id="dropdown-basic-button" style={{ color: "#FFF" }}
                                title={loginData.firstName || ""} menuAlign={{ lg: 'right' }} variant="link">
                                <Dropdown.Item eventKey="1" onClick={logout}> Log out</Dropdown.Item>

                            </DropdownButton>
                        </Nav>

                    </Navbar.Text>
                </Navbar.Collapse>
            </Navbar>
        </>
    );
}

export default connect(
    (state) => {
        return {
            loginDatauser: state.login.loginData
        }
    },
    {
        loginUserData,
        setuserdata,
        logUser
    }
)(NavbarTop);