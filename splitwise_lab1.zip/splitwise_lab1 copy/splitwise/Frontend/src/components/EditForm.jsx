import React from "react";
import { Container, Row, Col, Form, Button } from 'react-bootstrap';

function UserForm({
    errors,
    handleBlur,
    handleChange,
    handleSubmit,
    isNumber,
    touched,
    values
}) {

    return (
        <div>

            <form onSubmit={handleSubmit} autoComplete="off">
                <Row>
                    <Col md={7}>
                        <Row>
                            <Col md={5}>
                                <div className="profile-img" style={{ backgroundImage: `url(${'./user.jpg'})` }}></div>

                                <Form.File id="formcheck-api-regular">
                                    <Form.File.Label>Change your avatar</Form.File.Label>
                                    <Form.File.Input name="photo" onChange={handleChange} value={values.photo} />
                                    {touched.photo && errors.photo}

                                </Form.File>
                            </Col>
                            <Col md={7}>
                                <div className="form-group">
                                    <label> First Name *  </label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        id="first-name-input"
                                        placeholder="Enter first name"
                                        value={values.firstName}
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                        name="firstName"
                                        required
                                    />
                                    {touched.firstName && errors.firstName}

                                </div>

                                <div className="form-group">
                                    <label>
                                        Email address  </label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        id="email"
                                        placeholder="Enter email"
                                        value={values.email}
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                        name="email"
                                        required
                                    />
                                    {touched.email && errors.email}
                                </div>
                                <div className="form-group">
                                    <label>
                                        your phone number  </label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        id="last-name-input"
                                        placeholder="Enter phone"
                                        value={values.phone}
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                        name="phone"
                                        onKeyDown={isNumber}

                                        required
                                    />
                                    {touched.phone && errors.phone}

                                </div>
                            </Col>
                        </Row>
                    </Col>

                    <Col md={5}>

                        <Form.Group controlId="exampleForm.ControlSelect1">
                            <Form.Label>your default currency</Form.Label>
                            <Form.Control name="currency" as="select" value={values.currency}
                                onChange={handleChange}
                                onBlur={handleBlur}>
                                <option>USD</option>
                                <option>KWD</option>
                                <option>BHD</option>
                                <option>GBP</option>
                                <option>EUR</option>
                                <option>CAD</option>

                            </Form.Control>

                        </Form.Group>
                        <Form.Group>
                            <Form.Label>your time zone</Form.Label>
                            <Form.Control value={values.time}
                                onChange={handleChange}
                                onBlur={handleBlur} name="time" size="sm" type="text" placeholder="Small text" defaultValue={new Date()} />
                        </Form.Group>
                        <Form.Group controlId="exampleForm.ControlSelect1">
                            <Form.Label> language </Form.Label>
                            <Form.Control name="language" as="select" value={values.currency}
                                onChange={handleChange}
                                onBlur={handleBlur}>
                                <option>English</option>
                                <option>Spanish</option>
                                <option>Japanese</option>

                            </Form.Control>

                            {touched.language && errors.language}

                        </Form.Group>
                    </Col>
                </Row>
                <Row>
                    <Col>

                        <div className="form-group pull-right">
                            <Button type="submit" variant="warning">  save  </Button>
                        </div>
                    </Col>
                </Row>
            </form>
        </div>
    );
}

export default UserForm;
