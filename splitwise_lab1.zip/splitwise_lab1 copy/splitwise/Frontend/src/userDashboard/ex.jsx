import React, { useRef, useState, useEffect } from 'react';



class CreateGroup extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            Hobbies: []
        };
    }

    addHobby(e) {
        e.preventDefault();
        this.setState(prevState => ({ Hobbies: [...prevState.Hobbies, ""] }));
    }

    handleChange(i, event) {
        let Hobbies = [...this.state.Hobbies];
        Hobbies[i] = event.target.value;
        this.setState({ Hobbies });
    }

    removeClick(i) {
        let Hobbies = [...this.state.Hobbies];
        Hobbies.splice(i, 1);
        this.setState({ Hobbies });
    }

    render() {
        const widthStyle = {
            width: "15rem"
        };

        return (
            <div className="App">
                < div className={!isOpen ? "page-wrapper" : 'page-wrapper page-side'}>
                    <div id="wrapper" className={isOpen ? "toggled" : ''}>
                        <div id="sidebar-wrapper" >
                            <SidBar />
                        </div>
                        {console.log(errors, "ffff")}
                        <div id="page-content-wrapper" >
                            <nav className="navbar navbar-expand-lg navbar-light bg-light border-bottom">
                                <button className="btn btn-primary" id="menu-toggle" onClick={Toggle}>Toggle Menu</button>

                                <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                    <span className="navbar-toggler-icon"></span>
                                </button>

                                <div className="collapse navbar-collapse" id="navbarSupportedContent">
                                    <ul className="navbar-nav ml-auto mt-2 mt-lg-0">
                                        <li className="nav-item active">
                                            <a className="nav-link" href="#">Home <span className="sr-only">(current)</span></a>
                                        </li>
                                        <li className="nav-item">
                                            <a className="nav-link" href="#">Link</a>
                                        </li>
                                        <li className="nav-item dropdown">
                                            <a className="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                Dropdown
              </a>
                                            <div className="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                                <a className="dropdown-item" href="#">Action</a>
                                                <a className="dropdown-item" href="#">Another action</a>
                                                <div className="dropdown-divider"></div>
                                                <a className="dropdown-item" href="#">Something else here</a>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </nav>

                            <div className="container-fluid">
                                <form>
                                    <label>
                                        Hobbies:
              <input type="text" name="hobby" />
                                    </label>
                                    <br />
                                    <br />

                                    {this.state.Hobbies.map((el, i) => {
                                        return (
                                            <div key={i}>
                                                <input
                                                    type="text"
                                                    value={el || ""}
                                                    onChange={this.handleChange.bind(this, i)}
                                                />
                                                <input
                                                    type="button"
                                                    value="remove"
                                                    onClick={this.removeClick.bind(this, i)}
                                                />
                                            </div>
                                        );
                                    })}

                                    <button onClick={this.addHobby.bind(this)}>ADD Hobby</button>
                                </form>
                            </div></div>
                    </div>
                </ div>
            </div>
        );
    }
}

export default CreateGroup;