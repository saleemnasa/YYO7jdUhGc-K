import { Container, Row, Col, Form, Button, ListGroup, Modal } from 'react-bootstrap';
import React, { useState, useEffect } from 'react';
import { BASEURL } from '../constants'
import axios from 'axios';
class AddExpenses extends React.Component {


  constructor(props) {
    super(props);
    this.state = {
      description: '',
      amount: ''
    };

    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleChange(event) {
    const { name, value } = event.target;
    console.log(name, value)
    this.setState({ [name]: value });
  }

  handleSubmit(event) {
    console.log(this.state.description, 'sdfs', this.state.amount);

    const useron = localStorage.getItem("loginUser");
    var obj = {};
    console.log(this.state.description, 'sdfs', this.state.amount);
    obj.description = this.state.description;
    obj.amount = this.state.amount;
    obj.groupId = this.props.groupId;
    obj.groupListData = this.props.groupListData;
    // const onuser = JSON.parse(useron);
    // const group = { group_list: items, group_name: groupdata.group_name, avatar: '', user_id: onuser.id }
    // const formData = new FormData();
    // formData.append('group', JSON.stringify(group));
    // formData.append('myImage', groupPhoto);
    const userDetails = JSON.parse(localStorage.getItem('Usertoken'));
    const config = { headers: { Authorization: userDetails } };
    axios.post(BASEURL + "/saveExp", obj, config)
      .then((response) => {
        // alert("The file is successfully uploaded");
        console.log(response)
        this.props.onHide()
        // if (response.success === true) {
        //   history.push("/dashboard");
        // }
      }).catch((error) => {
      });
    event.preventDefault();
  }
  render() {
    console.log(this.props)
    return (
      <Modal
        {...this.props}
        size="sm"
        aria-labelledby="contained-modal-title-vcenter"
        centered
      >
        <Modal.Header closeButton>
          <h2 className="fontsiize16"> Add an Expense</h2>
        </Modal.Header>
        <Modal.Body>
          <h4 className="fontsiize14"> {this.props.groupName}</h4>
          <form onSubmit={this.handleSubmit}>
            <div class="form-group">


              <input className="form-control form-control-sm" placeholder=" Enter  a Description" type="text" name='description' value={this.state.description} onChange={this.handleChange} />
            </div>
            <div class="form-group">

              <input className="form-control form-control-sm" type="text" placeholder="C$" name='amount' value={this.state.amount} onChange={this.handleChange} />
            </div>

            <input type="submit" value="Submit" />
          </form>
        </Modal.Body>

      </Modal>
    );
  }
}

export default AddExpenses;