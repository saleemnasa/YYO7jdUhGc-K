import React, { useRef, useState, useEffect } from 'react';
import { Container, Row, Col, Alert, Button, ListGroup, InputGroup, FormControl, Form } from 'react-bootstrap';
import SidBar from '../components/sideBar/sideBar';
import { BASEURL, BASEURL_img } from '../constants'
import { Link } from 'react-router-dom';
import NavbarTop from '../components/navbar/NavbarTop'
import AddExpenses from './addExpenses'
import axios from 'axios';
class Dashboard extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			isOpen: true,
			user: JSON.parse(localStorage.getItem("loginUser")) || {},
			profile: null,
			group: [],
			groupusers: [],
			modalShow: false,
			groupId: '',
			reqGroup: [],
			reqgroupusers: [],
			filterValue: '',
			owedAmount: 0.00,
			owedData: [],
			oweData: [],
			// modalShow: false,
			// groupId: ''
		};
	}
	componentDidMount() {
		this.handledata();
	}

	handledata() {
		// const userDetails = JSON.parse(localStorage.getItem("userDetails"));
		axios
			.get(BASEURL + "/recentActivity", {
				headers: { Authorization: JSON.parse(localStorage.getItem('Usertoken')) }
			})
			.then(response => {
				// console.log(response, 'response
				// var owedData = response.data.owedData;
				var oweData = response.data.oweData;
				// 	console.log(activeData);
				// 	this.setState({ group: activeData })
				// 	if (activeData.length > 0) {
				// 		this.setState({ groupusers: activeData[0].groupListData, groupId: activeData[0].id })
				// 	}
				var owedDatas = [];
				var owedAmount = 0;
				var oweDatas = [];
				var oweAmount = 0;
				// for (let od = 0; od < owedData.length; od++) {
				// 	const element = owedData[od];
				// 	var groupExpeData = element.groupExpeData;
				// 	for (let i = 0; i < groupExpeData.length; i++) {
				// 		const elementin = groupExpeData[i];
				// 		elementin.amount = Number(elementin.amount).toFixed(2);
				// 		elementin.name = element.name;
				// 		owedAmount += Number(elementin.amount)
				// 		owedDatas.push(elementin);
				// 	}
				// }
				for (let od = 0; od < oweData.length; od++) {
					const element = oweData[od];
					var groupExpeData = element.groupExpeData;
					for (let i = 0; i < groupExpeData.length; i++) {
						const elementin = groupExpeData[i];
						elementin.amount = Number(elementin.amount).toFixed(2);
						oweAmount += Number(elementin.amount)
						elementin.name = element.name;
						elementin.firstName = elementin.userData.firstName;
						elementin.group_member = element.groupData && element.groupData.group_member;
						oweDatas.push(elementin);
					}
				}
				// this.setState({ owedData: owedDatas, owedAmount: Number(owedAmount).toFixed(2) })
				this.setState({ oweData: oweDatas })
				// 	if (requestData.length > 0) {
				// 		this.setState({ reqgroupusers: requestData[0].groupListData, groupId: requestData[0].id })
				// 	}
			})
			.catch(error => {
				console.log("Error fetching and parsing data", error);
				if (error == "Error: Request failed with status code 401") {
					// localStorage.removeItem("Usertoken");
					// localStorage.removeItem("loginUser");
					// this.props.history.push("/");
				}
			});
	}


	handleSettle = (e) => {
		// access to e.target here
		// console.log(e, data);
		// var owedData = this.state.owedData;
		// var oweData = this.state.oweData;
		var expArray = [];
		for (let index = 0; index < this.state.owedData.length; index++) {
			const element = this.state.owedData[index];
			expArray.push(element.id)

		}
		for (let index = 0; index < this.state.oweData.length; index++) {
			const element = this.state.oweData[index];
			expArray.push(element.id)
		}
		console.log(expArray)

		const userDetails = JSON.parse(localStorage.getItem('Usertoken'));
		const config = { headers: { Authorization: userDetails } };
		var obj = {};
		obj.expArray = expArray;
		axios.post(BASEURL + "/settleExp", obj, config)
			.then((response) => {
				// alert("The file is successfully uploaded");
				this.handledata();
				// if (response.success === true) {
				//   history.push("/dashboard");
				// }
			}).catch((error) => {
			});
	}

	toggled() {
		// console.log(state)
		const { isOpen } = this.state
		// var body = document.body;
		if (isOpen === true) {

			this.setState({
				isOpen: false
			})

			// body.classList.add("toggled");
		} else {
			this.setState({
				isOpen: true
			})
			// body.classList.remove("toggled");
		}
	}
	setModalShow = () => {
		this.setState({ modalShow: !this.state.modalShow })
	}


	// Toggle() {
	//     
	// }
	getDateFormat(date) {
		var dateObj = new Date(date);
		var month = dateObj.getUTCMonth() + 1; //months from 1-12
		var day = dateObj.getUTCDate();
		var year = dateObj.getUTCFullYear();

		return (month + "-" + day + "-" + year);
	}
	searchGN = (e) => {
		console.log(e.target)
		this.setState({ filterValue: e.target.value });
	}
	render() {
		const { group, groupusers, modalShow, groupId, reqGroup, owedAmount, owedData, oweData, oweAmount } = this.state;
		// return (
		//     <form onSubmit={this.handleSubmit}>
		//         <label>
		//             Name:
		//     <input type="text" value={this.state.firstName} onChange={this.handleChange} />
		//         </label>
		//         <input type="submit" value="Submit" />
		//     </form>
		// );
		return (


			< div className={!this.state.isOpen ? "page-wrapper" : 'page-wrapper page-side'}>
				<div id="wrapper" className={this.state.isOpen ? "toggled" : ''}>
					<div id="sidebar-wrapper" >
						<SidBar />
					</div>

					<div id="page-content-wrapper">
						<NavbarTop toggled={this.toggled} />
						<div className="container-fluid">
							<Container >
								<div className="w-75 d-auto">
									{/* <Row>
                  <Col md={12}>
                    <h3 className="mt-3 fontsize20"> Request groups </h3>
                  </Col>
                  <Col md={4}>
                    
                    <ListGroup>

                      
                    </ListGroup>
                  </Col>

                </Row> */}

									<Row>
										<Col md={12}>
											<h3 className="mt-3 fontsize20"> Recent Activity </h3>
										</Col>

									</Row>
									<Row>

										<Col md={12}>
											<InputGroup className="mb-3">
												<FormControl
													placeholder="Search Activity"
													aria-label="Search Activity"
													aria-describedby="basic-addon2"
													onChange={this.searchGN}
												/>
												<InputGroup.Append>
													<InputGroup.Text id="basic-addon2"> Activity</InputGroup.Text>
												</InputGroup.Append>
											</InputGroup>
										</Col>
									</Row>

									<Row>
										<Col md={12}>
											{['radio'].map((type) => (
												<div key={`custom-inline-${type}`} className="mb-3">

													<Form.Check
														custom
														inline
														label="sort by newest"
														type={type}
														id={`custom-inline-${type}-2`}
													/>
													<Form.Check
														custom
														inline

														label="sort by oldest"
														type={type}
														id={`custom-inline-${type}-3`}
													/>
												</div>
											))}
										</Col>

									</Row>
									<Row>
										<Col md={12}>
											<ListGroup>

												{oweData.filter(user => {
													console.log(user.group_member, this.state.filterValue)
													return user.group_member.toLowerCase().indexOf((this.state.filterValue).toLowerCase()) > -1;
												}).map((usergroup, i) => (

													<ListGroup.Item className="m" style={{ cursor: 'pointer' }}
														key={i} onClick={((e) => this.handleusers(e, usergroup))}
													>
														<Row className="d-flex justify-content-center">
															<Col md={1} >
																<div className="profilelist fontsiize14 pt-4">
																	<svg xmlns="http://www.w3.org/2000/svg" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 512 512" style={{ width: "20px" }}>
																		<g>
																			<g>
																				<path d="M5.224,0v512h501.551V0H5.224z M36.571,31.347h313.469v62.694H36.571V31.347z M245.551,480.653H36.571V125.388h313.469    v250.776h-104.49V480.653z M276.898,407.51h50.977l-50.977,50.977V407.51z M412.735,480.653H299.063l82.324-82.324V125.388h31.347    V480.653z M412.735,94.041h-31.347V31.347h31.347V94.041z M475.429,480.653h-31.347V125.388h31.347V480.653z M475.429,94.041    h-31.347V31.347h31.347V94.041z" />
																			</g>
																		</g>

																	</svg>
																</div>
															</Col>
															<Col md={11}>
																<p className="m-0"><b>{usergroup.name} settled "{usergroup.group_member}" in "{usergroup.description}"</b></p>
																<p className="m-0">{usergroup.name}  paid {usergroup.firstName} C${usergroup.amount}</p>
																<p className="m-0 fontsiize12">	{this.getDateFormat(usergroup.createdAt)}</p>


															</Col>
														</Row>
													</ListGroup.Item>

												))}
											</ListGroup>

										</Col>
									</Row>
								</div>
							</Container>
						</div>

					</div>
				</div >

			</div>
		);
	}
}

export default Dashboard;