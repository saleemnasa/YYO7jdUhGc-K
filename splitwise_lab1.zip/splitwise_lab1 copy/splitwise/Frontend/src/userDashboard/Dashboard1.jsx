import React, { useRef, useState, useEffect } from 'react';
import { Container, Row, Col, Alert, Button, ListGroup, InputGroup, FormControl } from 'react-bootstrap';
import SidBar from '../components/sideBar/sideBar';
import { BASEURL, BASEURL_img } from '../constants'
import { Link } from 'react-router-dom';
import NavbarTop from '../components/navbar/NavbarTop'
import AddExpenses from './addExpenses'
import axios from 'axios';
class Dashboard extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isOpen: true,
      user: JSON.parse(localStorage.getItem("loginUser")) || {},
      profile: null,
      group: [],
      groupusers: [],
      modalShow: false,
      groupId: '',
      reqGroup: [],
      reqgroupusers: [],
      filterValue: ''
      // modalShow: false,
      // groupId: ''
    };
  }
  componentDidMount() {
    this.handledata();
  }

  handledata() {
    // const userDetails = JSON.parse(localStorage.getItem("userDetails"));
    axios
      .get(BASEURL + "/allgroup", {
        headers: { Authorization: JSON.parse(localStorage.getItem('Usertoken')) }
      })
      .then(response => {
        // console.log(response, 'response
        var activeData = response.data.activeData;
        var requestData = response.data.requestData;
        console.log(activeData);
        this.setState({ group: activeData })
        if (activeData.length > 0) {
          this.setState({ groupusers: activeData[0].groupListData, groupId: activeData[0].id })
        }
        this.setState({ reqGroup: requestData })
        if (requestData.length > 0) {
          this.setState({ reqgroupusers: requestData[0].groupListData, groupId: requestData[0].id })
        }
      })
      .catch(error => {
        console.log("Error fetching and parsing data", error);
        if (error == "Error: Request failed with status code 401") {
          // localStorage.removeItem("Usertoken");
          // localStorage.removeItem("loginUser");
          // this.props.history.push("/");
        }
      });
  }


  handleusers = (e, data) => {
    // access to e.target here
    console.log(e, data);
    this.setState({ groupId: data.id });
    if (data.groupListData.length > 0) {
      this.setState({ groupusers: data.groupListData, groupId: data.id });
    } else {
      this.setState({ groupusers: [] })
    }
    // axios
    //   .get(BASEURL + "/group/" + data.id, {
    //     headers: { Authorization: '' }
    //   })
    //   .then(response => {
    //     // console.log(response, 'response
    //     var inactiveData = response.data.inactiveData;
    //     console.log(inactiveData);
    //     this.setState({ groupusers: inactiveData })
    //   })
    //   .catch(error => {
    //     console.log("Error fetching and parsing data", error);
    //     if (error == "Error: Request failed with status code 401") {
    //       localStorage.removeItem("userDetails");
    //       this.props.history.push("/");
    //     }
    //   });
  }
  handleLeave = (e, data) => {
    if ((data.groupListData[0] && data.groupListData[0].groupExpeData.length)) {
      alert('You must settle your balances')
    } else {
      setTimeout(() => {
        var config = {
          headers: {
            Authorization: JSON.parse(localStorage.getItem('Usertoken'))

          }
        };
        var object = {};
        object.status = 3
        if (object) {
          axios
            .put(BASEURL + "/groupActive/" + data.groupListData[0].id, object, config)
            .then(response => {

              // loadTransition(true);
              // submit(fromJS(response.data), reducer);
              this.handledata();
              // history.push("/app/master/communications/alerts");
            })
            .catch(error => {
              console.log('Error fetching and parsing data', error);
              if (error === 'Error: Request failed with status code 401') {
                // localStorage.removeItem('userDetails');
                // history.push('/');
              }
            });
        }
      }, 500);
    }
  }
  handleActive = (e, data) => {
    // if ((data.groupListData[0] && data.groupListData[0].groupExpeData.length)) {
    //   alert('You must settle yoyr remaning amount')
    // } else {
    setTimeout(() => {
      var config = {
        headers: {
          Authorization: JSON.parse(localStorage.getItem('Usertoken'))

        }
      };
      var object = {};
      object.status = 2
      if (object) {
        axios
          .put(BASEURL + "/groupActive/" + data.groupListData[0].id, object, config)
          .then(response => {

            // loadTransition(true);
            // submit(fromJS(response.data), reducer);
            this.handledata();
            // history.push("/app/master/communications/alerts");
          })
          .catch(error => {
            console.log('Error fetching and parsing data', error);
            if (error === 'Error: Request failed with status code 401') {
              // localStorage.removeItem('userDetails');
              // history.push('/');
            }
          });
      }
    }, 500);
    // }
  }
  handleReject = (e, data) => {
    setTimeout(() => {
      var config = {
        headers: {
          Authorization: JSON.parse(localStorage.getItem('Usertoken'))

        }
      };
      var object = {};
      object.status = 0
      if (object) {
        axios
          .put(BASEURL + "/groupActive/" + data.groupListData[0].id, object, config)
          .then(response => {

            // loadTransition(true);
            // submit(fromJS(response.data), reducer);
            this.handledata();
            // history.push("/app/master/communications/alerts");
          })
          .catch(error => {
            console.log('Error fetching and parsing data', error);
            if (error === 'Error: Request failed with status code 401') {
              // localStorage.removeItem('userDetails');
              // history.push('/');
            }
          });
      }
    }, 500);
  }
  toggled() {
    // console.log(state)
    const { isOpen } = this.state
    // var body = document.body;
    if (isOpen === true) {

      this.setState({
        isOpen: false
      })

      // body.classList.add("toggled");
    } else {
      this.setState({
        isOpen: true
      })
      // body.classList.remove("toggled");
    }
  }
  setModalShow = () => {
    this.setState({ modalShow: !this.state.modalShow })
  }
  searchGN = (e) => {
    console.log(e.target)
    this.setState({ filterValue: e.target.value });
  }

  // Toggle() {
  //     
  // }

  render() {
    const { group, groupusers, modalShow, groupId, reqGroup, reqgroupusers } = this.state;
    // return (
    //     <form onSubmit={this.handleSubmit}>
    //         <label>
    //             Name:
    //     <input type="text" value={this.state.firstName} onChange={this.handleChange} />
    //         </label>
    //         <input type="submit" value="Submit" />
    //     </form>
    // );
    return (


      < div className={!this.state.isOpen ? "page-wrapper" : 'page-wrapper page-side'}>
        <div id="wrapper" className={this.state.isOpen ? "toggled" : ''}>
          <div id="sidebar-wrapper" >
            <SidBar />
          </div>

          <div id="page-content-wrapper">
            <NavbarTop toggled={this.toggled} />
            <div className="container-fluid">
              <Container >
                <div className="w-75 d-auto">
                  {/* <Row>
                  <Col md={12}>
                    <h3 className="mt-3 fontsize20"> Request groups </h3>
                  </Col>
                  <Col md={4}>
                    
                    <ListGroup>

                      
                    </ListGroup>
                  </Col>

                </Row> */}

                  <Row>
                    <Col md={12}>
                      <h3 className="mt-3 fontsize20"> My groups </h3>
                    </Col>
                  </Row>
                  <Row>
                    <Col md={12}>
                      <h5 className="fontsiize16">Group Invitation</h5>

                    </Col>
                    <Col md={12}>



                      {reqGroup.length > 0 ? reqGroup.map((usergroup, i) => (
                        <>


                          <Alert className="mb-2 w-100 p-2"
                            key={i} onClick={((e) => this.handleusers(e, usergroup))} variant={"secondary"} > {usergroup.group_member}

                            <div className="pull-right" style={{ marginTop: "-3px" }}>
                              <Button className="mr-2 " style={{ background: "#5ebea3", border: "#5ebea3" }} variant="primary" size="sm" onClick={((e) => this.handleActive(e, usergroup))}>
                                Accept
          </Button>
                              <Button variant="danger" size="sm" onClick={((e) => this.handleReject(e, usergroup))}>
                                Decline
          </Button></div>
                          </Alert>

                        </>
                      ))
                        : <p className="p-3" style={{ background: '#ccc', }}> No Invitation</p>
                      }

                    </Col>
                  </Row>
                  <Row>
                    <Col md={12}>
                      <h5 className="fontsiize16">Active Group</h5>

                    </Col>
                    <Col md={12}>
                      <InputGroup className="mb-3">
                        <FormControl
                          placeholder="Search Group Name"
                          aria-label="Search Group Name"
                          aria-describedby="basic-addon2"
                          onChange={this.searchGN}
                        />
                        <InputGroup.Append>
                          <InputGroup.Text id="basic-addon2">Search Group Name</InputGroup.Text>
                        </InputGroup.Append>
                      </InputGroup>
                    </Col>
                    <Col md={12}>
                      <ListGroup>

                        {group.filter(user => {
                          console.log(user.group_member, this.state.filterValue)
                          return user.group_member.toLowerCase().indexOf((this.state.filterValue).toLowerCase()) > -1;
                        }).map((usergroup, i) => (

                          <ListGroup.Item className="m" style={{ cursor: 'pointer' }}
                            key={i} onClick={((e) => this.handleusers(e, usergroup))}
                          >   <Link to={'/my-groups/' + usergroup.id}><div className="profilelist" style={{
                            backgroundImage:
                              (usergroup.group_photo ?
                                `url(${BASEURL_img + '/' + usergroup.group_photo})`
                                : `url(${'./user.jpg'})`)
                          }}></div>{usergroup.group_member}
                            </Link>
                            <div className="pull-right" style={{ marginTop: "-3px" }}>

                              <Button variant="danger" size="sm" onClick={((e) => this.handleLeave(e, usergroup))}>
                                Leave
      </Button></div></ListGroup.Item>

                        ))}
                      </ListGroup>

                    </Col>
                  </Row>
                  <Row>
                    <Col md={4}>

                    </Col>

                    <Col md={5}>
                      {/* <Button variant="primary" onClick={() => this.setModalShow()}>
                        Add an expense
                    </Button> */}
                      <AddExpenses
                        show={modalShow}
                        onHide={() => this.setModalShow()}
                        groupId={groupId}
                      />

                    </Col>
                    {/* <Col md={3}>
                      {groupusers.map((usermail, i) => (
                        <div className="user" key={i}>{usermail.email}</div>
                      ))}
                    </Col> */}
                  </Row>

                </div>
              </Container>
            </div>

          </div>
        </div >

      </div>
    );
  }
}

export default Dashboard;