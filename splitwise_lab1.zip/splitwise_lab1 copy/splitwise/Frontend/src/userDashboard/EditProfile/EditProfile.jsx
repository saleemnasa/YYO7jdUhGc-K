import React, { useRef, useState, useEffect } from 'react';
import { Container, Row, Col, Form, Button } from 'react-bootstrap';
import { useHistory } from "react-router-dom";
import SidBar from '../../components/sideBar/sideBar';
import ReactUploadImage from '../../components/UploadImage/UploadImage'
import { BASEURL, BASEURL_img } from '../../constants'
import NavbarTop from '../../components/navbar/NavbarTop'

import axios from 'axios';
class NameForm extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            isOpen: true,
            user: JSON.parse(localStorage.getItem("loginUser")) || {},
            profile: null
        };

        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    componentDidMount() {

    }

    handleChange(event) {
        // console.log(event.target.name)
        var user = this.state.user;
        user[event.target.name] = event.target.value;
        // console.log(user)
        this.setState({ user: user });
    }

    handleSubmit(event) {
        // alert('A name was submitted: ' + this.state.user);
        console.log(this.state.user)
        event.preventDefault();
        const formData = new FormData();
        formData.append('user', JSON.stringify(this.state.user));
        formData.append('myImage', this.state.profile);
        const config = { headers: { 'content-type': 'multipart/form-data' } };
        axios.put(BASEURL + "/users/" + this.state.user.id, formData, config)
            .then((response) => {
                // alert("The file is successfully uploaded");
                console.log(response)
                var data = response.data.status;
                if (data) {
                    localStorage.removeItem('loginUser', null);
                    // localStorage.removeItem('Usertoken', null);
                    localStorage.setItem('loginUser', JSON.stringify(response.data.userData));
                    // localStorage.setItem('Usertoken', JSON.stringify(response.data.userData.token));
                    // this.props.history.push("/dashboard");
                    // window.location.reload()
                    this.setState({ user: JSON.parse(localStorage.getItem("loginUser")) || {} });
                } else {

                }
            }).catch((error) => {
            });
    }

    handleUpload = (value) => {
        console.log(value)
        this.setState({ profile: value });
    }
    toggled() {
        // console.log(state)
        const { isOpen } = this.state
        // var body = document.body;
        if (isOpen === true) {

            this.setState({
                isOpen: false
            })

            // body.classList.add("toggled");
        } else {
            this.setState({
                isOpen: true
            })
            // body.classList.remove("toggled");
        }
    }
    v

    // Toggle() {
    //     
    // }

    render() {
        const { user } = this.state;

        console.log(user.photo)
        // return (
        //     <form onSubmit={this.handleSubmit}>
        //         <label>
        //             Name:
        //     <input type="text" value={this.state.firstName} onChange={this.handleChange} />
        //         </label>
        //         <input type="submit" value="Submit" />
        //     </form>
        // );
        return (
            < div className={!this.state.isOpen ? "page-wrapper" : 'page-wrapper page-side'}>
                <div id="wrapper" className={this.state.isOpen ? "toggled" : ''}>
                    <div id="sidebar-wrapper" >
                        <SidBar />
                    </div>

                    <div id="page-content-wrapper" >
                        <NavbarTop toggled={this.toggled} />

                        <div className="container-fluid">

                            <Container>
                                <Row>
                                    <Col>
                                        <h3 className="mt-3 fontsize20"> Your account </h3>
                                    </Col>
                                </Row>


                                <form onSubmit={this.handleSubmit} className="mt-1 mb-3 pr-3 pl-3 w-100 accountform"  >
                                    <Row>
                                        <Col md={8}>
                                            <Row>
                                                <Col md={5}>
                                                    <div className="profile-img" style={{
                                                        backgroundImage:
                                                            (user.photo ?
                                                                `url(${BASEURL_img + '/' + user.photo})`
                                                                : `url(${'./user.jpg'})`)
                                                    }}></div>
                                                    <Form.File id="formcheck-api-regular">
                                                        <Form.File.Label>Change your avatar</Form.File.Label>
                                                        {/* <Form.File.Input /> */}
                                                        <ReactUploadImage handleUpload={this.handleUpload} />
                                                    </Form.File>
                                                </Col>
                                                <Col md={7}>
                                                    <div className="form-group">
                                                        <label>your name</label>

                                                        <div>

                                                            <input name="firstName" type="text" value={user.firstName} onChange={this.handleChange} className="form-control" />

                                                        </div>


                                                    </div>
                                                    <div className="form-group">
                                                        <label>your email address</label>

                                                        <div >
                                                            <input
                                                                name="email"
                                                                type="email"
                                                                value={user.email}
                                                                onChange={this.handleChange}
                                                                className="form-control"
                                                            />
                                                        </div>

                                                    </div>

                                                    <div className="form-group">
                                                        <label>your phone number</label>

                                                        <div >
                                                            <input
                                                                name="phone"
                                                                type="text"
                                                                value={user.phone}
                                                                onChange={this.handleChange}
                                                                className="form-control"
                                                            />
                                                        </div>


                                                    </div>

                                                </Col>

                                            </Row>
                                        </Col>
                                        <Col md={4}>
                                            <Form.Group controlId="exampleForm.ControlSelect1">
                                                <Form.Label>your default currency</Form.Label>
                                                <Form.Control name="currency" as="select" value={user.currency} onChange={this.handleChange}>
                                                    <option>select your currency </option>
                                                    <option>USD</option>
                                                    <option>KWD</option>
                                                    <option>BHD</option>
                                                    <option>GBP</option>
                                                    <option>EUR</option>
                                                    <option>CAD</option>

                                                </Form.Control>
                                            </Form.Group>
                                            <Form.Group>
                                                <Form.Label>your time zone</Form.Label>
                                                <Form.Control onChange={this.handleChange} size="sm" type="text" placeholder="Small text" value={user.time} defaultValue={new Date()} />
                                            </Form.Group>
                                            <Form.Group controlId="exampleForm.ControlSelect1">
                                                <Form.Label> language </Form.Label>
                                                <Form.Control name="language" as="select" onChange={this.handleChange} value={user.language}>
                                                    <option>select your language </option>
                                                    <option>English</option>
                                                    <option>Spanish</option>
                                                    <option>Japanese</option>

                                                </Form.Control>
                                            </Form.Group>

                                        </Col>
                                        <button type="submit" className="mt-3 btn btn-primary">Submit</button>

                                    </Row>
                                </form>

                            </Container>
                        </div>

                    </div>
                </div >

            </div>
        );
    }
}

export default NameForm;