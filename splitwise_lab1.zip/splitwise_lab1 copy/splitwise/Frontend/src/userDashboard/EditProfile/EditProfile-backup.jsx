import React, { useRef, useState, useEffect } from 'react';

import { Container, Row, Col, Form, Button } from 'react-bootstrap';
import SidBar from '../../components/sideBar/sideBar';
import { connect } from 'react-redux'
import { loginUserData, setuserdata, logUser } from '../../redux/login';
import useForm from "../../components/Form/useForm";
import useForm1 from "../../components/Form/useForm1";

import validate from './loginRules';
const nameValidation = (fieldName, fieldValue) => {
    if (fieldValue.trim() === "") {
        return `${fieldName} is required`;
    }
    if (/[^a-zA-Z -]/.test(fieldValue)) {
        return "Invalid characters";
    }
    if (fieldValue.trim().length < 3) {
        return `${fieldName} needs to be at least three characters`;
    }
    return null;
};

const emailValidation = email => {
    if (
        /^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/.test(
            email
        )
    ) {
        return null;
    }
    if (email.trim() === "") {
        return "Email is required";
    }
    return "Please enter a valid email";
};

const ageValidation = age => {
    if (!age) {
        return "Age is required";
    }
    if (age < 18) {
        return "Age must be at least 18";
    }
    if (age > 99) {
        return "Age must be under 99";
    }
    return null;
};

const validate = {
    firstName: name => nameValidation("First Name", name),
    lastName: name => nameValidation("Last Name", name),
    email: emailValidation,
    age: ageValidation
};

const initialValues = {
    age: 10,
    email: "no@email",
    firstName: "Mary",
    lastName: "Jane"
};

const EditProfile = (props) => {
    const {
        values,
        errors,
        handleChange,
        handleSubmit,
    } = useForm1(login, validate);
    function login() {
        console.log(values, "values")

    }
    const [isOpen, setisOpen] = useState(true);
    const [isMobile, setisMobile] = useState(false);


    function Toggle() { setisOpen(!isOpen) };

    const [user, setUser] = useState(JSON.parse(localStorage.getItem("loginUser")) || {});
    const [edit, setonUseredit] = useState(0);


    const handleResize = () => {
        if ((window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth) <= 764) {
            setisMobile(true);
            setisOpen(false);
        } else {
            setisMobile(false);
            // setisOpen(false);
        }
    }
    useEffect(() => {
        window.addEventListener("resize", handleResize, false);
    }, []);

    function editInput(i) {
        setonUseredit(i)
        // createdAt: "2021-03-07T13:32:10.000Z"
        // dateofbirth: "2021-03-18"
        // email: "vamsi@gmail.com"
        // first: "vamsi chowdary"
        // gender: "male"
        // id: 1
        // last: "fdfdfd"
        // password: "$2b$10$sK3c2RbSckMbfYY/HahNpuWdDaYLeJjikr2cMerT71RBUTH7wZIuu"
        // phone: null
        // updatedAt: "2021-03-07T13:32:10.000Z"
    }
    function onhandleChange(params) {
        handleChange(params)
    }
    return (
        < div className={!isOpen ? "page-wrapper" : 'page-wrapper page-side'}>
            <div id="wrapper" className={isOpen ? "toggled" : ''}>
                <div id="sidebar-wrapper" >
                    <SidBar />
                </div>

                <div id="page-content-wrapper" >
                    <nav className="navbar navbar-expand-lg navbar-light bg-light border-bottom">
                        <button className="btn btn-primary" id="menu-toggle" onClick={Toggle}>Toggle Menu</button>

                        <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <span className="navbar-toggler-icon"></span>
                        </button>

                        <div className="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul className="navbar-nav ml-auto mt-2 mt-lg-0">
                                <li className="nav-item active">
                                    <a className="nav-link" href="#">Home <span className="sr-only">(current)</span></a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" href="#">Link</a>
                                </li>
                                <li className="nav-item dropdown">
                                    <a className="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        Dropdown
              </a>
                                    <div className="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                        <a className="dropdown-item" href="#">Action</a>
                                        <a className="dropdown-item" href="#">Another action</a>
                                        <div className="dropdown-divider"></div>
                                        <a className="dropdown-item" href="#">Something else here</a>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </nav>

                    <div className="container-fluid">

                        <Container>
                            <Row>
                                <Col>
                                    <h2 className="mt-3 fontsize20"> Your account </h2>
                                </Col>
                            </Row>


                            <form onSubmit={handleSubmit} noValidate className="mt-1 mb-3 pr-3 pl-3 w-100 accountform"  >
                                <Row>
                                    <Col md={8}>
                                        <Row>
                                            <Col md={5}>
                                                <div className="profile-img" style={{ backgroundImage: `url(${'./user.jpg'})` }}></div>

                                                <Form.File id="formcheck-api-regular">
                                                    <Form.File.Label>Change your avatar</Form.File.Label>
                                                    <Form.File.Input />
                                                </Form.File>
                                            </Col>
                                            <Col md={7}>
                                                <div>
                                                    <label>your name</label>
                                                    {edit === 1 ?
                                                        <div className={errors.firstName ? "inputError" : ''}>

                                                            <input
                                                                name="first"
                                                                type="text"
                                                                value={user.firstName}
                                                                className="form-control"

                                                            />
                                                            {errors.firstName && <p className="error">{errors.firstName}</p>}
                                                        </div>
                                                        :
                                                        <p className="font-weight700">{user.firstName} <span className="ml-3 cursorpointer" onClick={e => editInput(1)}>Edit</span></p>
                                                    }

                                                </div>
                                                <div>
                                                    <label>your email address</label>
                                                    {edit === 2 ?
                                                        <div >
                                                            <input
                                                                name="email"
                                                                type="email"
                                                                defaultValue={user.email}
                                                                onChange={handleChange}
                                                                className="form-control"
                                                            />
                                                            {errors.email && <p className="error">{errors.email}</p>}
                                                        </div>
                                                        :
                                                        <p className="font-weight700">{user.email} <span className="ml-3 cursorpointer" onClick={e => editInput(2)}>Edit</span></p>
                                                    }

                                                </div>

                                                <div className="mb-3">
                                                    <label>your phone number</label>
                                                    {edit === 3 ?
                                                        <div className={errors.phone ? "inputError" : ''}>
                                                            <input
                                                                name="phone"
                                                                type="text"
                                                                defaultValue={values.phone}
                                                                onChange={handleChange}
                                                                className="form-control"
                                                            />
                                                            {errors.phone && <p className="error">{errors.phone}</p>}
                                                        </div>
                                                        :
                                                        <>
                                                            {values.phone ?
                                                                <p className="font-weight700">{values.phone} <span className="ml-3 cursorpointer" onClick={e => editInput(3)}>Edit</span></p>
                                                                :
                                                                <p className="font-weight700">{!values.phone ? 'null ' : 'null'} <span className="ml-3 cursorpointer" onClick={e => editInput(3)}>Edit</span></p>

                                                            }
                                                        </>

                                                    }
                                                </div>

                                            </Col>

                                        </Row>
                                    </Col>
                                    <Col md={4}>
                                        <Form.Group controlId="exampleForm.ControlSelect1">
                                            <Form.Label>your default currency</Form.Label>
                                            <Form.Control name="currency" as="select" onChange={handleChange}>
                                                <option>USD</option>
                                                <option>KWD</option>
                                                <option>BHD</option>
                                                <option>GBP</option>
                                                <option>EUR</option>
                                                <option>CAD</option>

                                            </Form.Control>
                                        </Form.Group>
                                        <Form.Group>
                                            <Form.Label>your time zone</Form.Label>
                                            <Form.Control onChange={handleChange} size="sm" type="text" placeholder="Small text" defaultValue={new Date()} />
                                        </Form.Group>
                                        <Form.Group controlId="exampleForm.ControlSelect1">
                                            <Form.Label> language </Form.Label>
                                            <Form.Control name="language" as="select" onChange={handleChange}>
                                                <option>English</option>
                                                <option>Spanish</option>
                                                <option>Japanese</option>

                                            </Form.Control>
                                        </Form.Group>

                                    </Col>
                                    <button type="submit" className="mt-3 btn btn-primary">Submit</button>

                                </Row>
                            </form>

                        </Container>
                    </div>

                </div>
            </div >

        </div>
    );
}

export default connect(
    (state) => {
        return {
            loginDatauser: state.login.loginData
        }
    },
    {
        loginUserData,
        setuserdata,
        logUser
    }
)(EditProfile);