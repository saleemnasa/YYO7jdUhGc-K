import React, { useRef, useState, useEffect } from 'react';

import { Container, Row, Col, Form, Button } from 'react-bootstrap';
import SidBar from '../../components/sideBar/sideBar';
import { connect } from 'react-redux'
import { loginUserData, setuserdata, logUser } from '../../redux/login';
import useForm from "../../components/Form/useForm";
import useForm1 from "../../components/Form/useForm1";

import validate from './loginRules';

const EditProfile = (props) => {
    const {
        values,
        errors,
        handleChange,
        handleSubmit,
    } = useForm1(login, validate);
    function login() {
        console.log(values, "values")

    }
    const [isOpen, setisOpen] = useState(true);
    const [isMobile, setisMobile] = useState(false);


    function Toggle() { setisOpen(!isOpen) };

    const [user, setUser] = useState(JSON.parse(localStorage.getItem("loginUser")) || {});



    const handleResize = () => {
        if ((window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth) <= 764) {
            setisMobile(true);
            setisOpen(false);
        } else {
            setisMobile(false);
            // setisOpen(false);
        }
    }
    useEffect(() => {
        window.addEventListener("resize", handleResize, false);
        handleChange2()
    }, []);

    function handleChange2() {
        const edit = { firstName: 'ram' }
        handleChange(edit)
        // console.log(values)
        // var userObject = JSON.parse(localStorage.getItem("loginUser")) || {};
        // for (let key in userObject) {
        //   // console.log(key)
        //   if (key == event.target.name) {
        //     setValues(values => ({ ...values, [event.target.name]: event.target.value }));
        //   } else {
        //     setValues(values => ({ ...values, [key]: userObject[key] }));
        //   }
        // }

    };



    return (
        < div className={!isOpen ? "page-wrapper" : 'page-wrapper page-side'}>
            <div id="wrapper" className={isOpen ? "toggled" : ''}>
                <div id="sidebar-wrapper" >
                    <SidBar />
                </div>

                <div id="page-content-wrapper" >
                    <nav className="navbar navbar-expand-lg navbar-light bg-light border-bottom">
                        <button className="btn btn-primary" id="menu-toggle" onClick={Toggle}>Toggle Menu</button>

                        <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <span className="navbar-toggler-icon"></span>
                        </button>

                        <div className="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul className="navbar-nav ml-auto mt-2 mt-lg-0">
                                <li className="nav-item active">
                                    <a className="nav-link" href="#">Home <span className="sr-only">(current)</span></a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" href="#">Link</a>
                                </li>
                                <li className="nav-item dropdown">
                                    <a className="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        Dropdown
              </a>
                                    <div className="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                        <a className="dropdown-item" href="#">Action</a>
                                        <a className="dropdown-item" href="#">Another action</a>
                                        <div className="dropdown-divider"></div>
                                        <a className="dropdown-item" href="#">Something else here</a>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </nav>

                    <div className="container-fluid">

                        <Container>
                            <Row>
                                <Col>
                                    <h2 className="mt-3 fontsize20"> Your account </h2>
                                </Col>
                            </Row>


                            <form onSubmit={handleSubmit} noValidate className="mt-1 mb-3 pr-3 pl-3 w-100 accountform"  >
                                <Row>
                                    <Col md={8}>
                                        <Row>
                                            <Col md={5}>
                                                <div className="profile-img" style={{ backgroundImage: `url(${'./user.jpg'})` }}></div>

                                                <Form.File id="formcheck-api-regular">
                                                    <Form.File.Label>Change your avatar</Form.File.Label>
                                                    <Form.File.Input />
                                                </Form.File>
                                            </Col>
                                            <Col md={7}>
                                                <div>
                                                    <label>your name</label>

                                                    <div className={errors.firstName ? "inputError" : ''}>

                                                        <input
                                                            name="first"
                                                            type="text"
                                                            defaultValue={user.firstName}
                                                            className="form-control"
                                                            onChange={handleChange}
                                                        />
                                                        {errors.firstName && <p className="error">{errors.firstName}</p>}
                                                    </div>


                                                </div>
                                                <div>
                                                    <label>your email address</label>

                                                    <div >
                                                        <input
                                                            name="email"
                                                            type="email"
                                                            defaultValue={user.email}
                                                            onChange={handleChange}
                                                            className="form-control"
                                                        />
                                                        {errors.email && <p className="error">{errors.email}</p>}
                                                    </div>

                                                </div>

                                                <div className="mb-3">
                                                    <label>your phone number</label>

                                                    <div className={errors.phone ? "inputError" : ''}>
                                                        <input
                                                            name="phone"
                                                            type="text"
                                                            defaultValue={values.phone}
                                                            onChange={handleChange}
                                                            className="form-control"
                                                        />
                                                        {errors.phone && <p className="error">{errors.phone}</p>}
                                                    </div>


                                                </div>

                                            </Col>

                                        </Row>
                                    </Col>
                                    <Col md={4}>
                                        <Form.Group controlId="exampleForm.ControlSelect1">
                                            <Form.Label>your default currency</Form.Label>
                                            <Form.Control name="currency" as="select" onChange={handleChange}>
                                                <option>USD</option>
                                                <option>KWD</option>
                                                <option>BHD</option>
                                                <option>GBP</option>
                                                <option>EUR</option>
                                                <option>CAD</option>

                                            </Form.Control>
                                        </Form.Group>
                                        <Form.Group>
                                            <Form.Label>your time zone</Form.Label>
                                            <Form.Control onChange={handleChange} size="sm" type="text" placeholder="Small text" defaultValue={new Date()} />
                                        </Form.Group>
                                        <Form.Group controlId="exampleForm.ControlSelect1">
                                            <Form.Label> language </Form.Label>
                                            <Form.Control name="language" as="select" onChange={handleChange}>
                                                <option>English</option>
                                                <option>Spanish</option>
                                                <option>Japanese</option>

                                            </Form.Control>
                                        </Form.Group>

                                    </Col>
                                    <button type="submit" className="mt-3 btn btn-primary">Submit</button>

                                </Row>
                            </form>

                        </Container>
                    </div>

                </div>
            </div >

        </div>
    );
}

export default connect(
    (state) => {
        return {
            loginDatauser: state.login.loginData
        }
    },
    {
        loginUserData,
        setuserdata,
        logUser
    }
)(EditProfile);