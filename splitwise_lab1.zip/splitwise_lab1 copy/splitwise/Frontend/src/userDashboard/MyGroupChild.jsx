import React, { useRef, useState, useEffect } from 'react';
import { Container, Row, Col, Alert, Button, ListGroup, InputGroup, FormControl } from 'react-bootstrap';
import SidBar from '../components/sideBar/sideBar';
import { BASEURL, BASEURL_img } from '../constants'

import NavbarTop from '../components/navbar/NavbarTop'
import AddExpenses from './addExpenses'
import axios from 'axios';
class Dashboard extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			isOpen: true,
			user: JSON.parse(localStorage.getItem("loginUser")) || {},
			profile: null,
			group: [],
			groupusers: [],
			modalShow: false,
			groupId: '',
			reqGroup: {},
			reqgroupusers: [],
			filterValue: ''
			// modalShow: false,
			// groupId: ''
		};
	}
	componentDidMount() {
		// console.log(this.props.match.params.groupId)
		this.handledata(this.props.match.params.groupId);
		this.setState({ user: JSON.parse(localStorage.getItem("loginUser")) || {} })
	}

	handledata(groupId) {
		// const userDetails = JSON.parse(localStorage.getItem("userDetails"));
		axios
			.get(BASEURL + "/groupData/" + groupId, {
				headers: { Authorization: JSON.parse(localStorage.getItem('Usertoken')) }
			})
			.then(response => {
				// console.log(response, 'response
				var activeData = response.data.activeData;
				var requestData = response.data.requestData;
				// console.log(activeData);
				// this.setState({ group: activeData })
				// if (activeData.length > 0) {
				//     this.setState({ groupusers: activeData[0].groupListData, groupId: activeData[0].id })
				// }
				var amount = 0
				var group = [];

				var groupListData = activeData.groupListData;
				this.setState({ reqGroup: activeData })


				if (activeData.groupListData.length > 0) {
					for (let am = 0; am < groupListData.length; am++) {
						const element = groupListData[am];
						var groupExpData = element.groupExpeData;
						if (groupExpData.length > 0) {
							for (let a = 0; a < groupExpData.length; a++) {
								const elementam = groupExpData[a];
								elementam.createDate = elementam.createdAt;
								elementam.expname = elementam.description;
								elementam.userName = elementam.userData && elementam.userData.firstName;
								elementam.amount = Number(elementam.amount).toFixed(2);
								elementam.name = element.name;
								console.log(element)
								group.push(elementam);
							}
						}
					}
				}
				this.setState({
					group: group.sort(function (a, b) {
						return b.id - a.id;
					})
				});
				// if (requestData.length > 0) {
				//     this.setState({ reqgroupusers: requestData[0].groupListData, groupId: requestData[0].id })
				// }
			})
			.catch(error => {
				console.log("Error fetching and parsing data", error);
				if (error == "Error: Request failed with status code 401") {
					// localStorage.removeItem("Usertoken");
					// localStorage.removeItem("loginUser");
					// this.props.history.push("/");
				}
			});
	}


	handleusers = (e, data) => {
		// access to e.target here
		console.log(e, data);
		this.setState({ groupId: data.id });
		if (data.groupListData.length > 0) {
			this.setState({ groupusers: data.groupListData, groupId: data.id });
		} else {
			this.setState({ groupusers: [] })
		}
		// axios
		//   .get(BASEURL + "/group/" + data.id, {
		//     headers: { Authorization: '' }
		//   })
		//   .then(response => {
		//     // console.log(response, 'response
		//     var inactiveData = response.data.inactiveData;
		//     console.log(inactiveData);
		//     this.setState({ groupusers: inactiveData })
		//   })
		//   .catch(error => {
		//     console.log("Error fetching and parsing data", error);
		//     if (error == "Error: Request failed with status code 401") {
		//       localStorage.removeItem("userDetails");
		//       this.props.history.push("/");
		//     }
		//   });
	}

	toggled() {
		// console.log(state)
		const { isOpen } = this.state
		// var body = document.body;
		if (isOpen === true) {

			this.setState({
				isOpen: false
			})

			// body.classList.add("toggled");
		} else {
			this.setState({
				isOpen: true
			})
			// body.classList.remove("toggled");
		}
	}
	setModalShow = () => {
		// this.handledata(this.state.reqGroup.id);
		this.setState({ modalShow: !this.state.modalShow })
	}
	setModalClose = () => {
		this.handledata(this.state.reqGroup.id);
		this.setState({ modalShow: !this.state.modalShow })
	}
	searchGN = (e) => {
		console.log(e.target)
		this.setState({ filterValue: e.target.value });
	}

	// Toggle() {
	//     
	// }
	getDateFormat(date) {
		var dateObj = new Date(date);
		var month = dateObj.getUTCMonth() + 1; //months from 1-12
		var day = dateObj.getUTCDate();
		var year = dateObj.getUTCFullYear();

		return (month + "/" + day + "/" + year);
	}
	render() {
		const { group, groupusers, modalShow, groupId, reqGroup, reqgroupusers } = this.state;
		// return (
		//     <form onSubmit={this.handleSubmit}>
		//         <label>
		//             Name:
		//     <input type="text" value={this.state.firstName} onChange={this.handleChange} />
		//         </label>
		//         <input type="submit" value="Submit" />
		//     </form>
		// );
		console.log(group)
		return (


			< div className={!this.state.isOpen ? "page-wrapper" : 'page-wrapper page-side'}>
				<div id="wrapper" className={this.state.isOpen ? "toggled" : ''}>
					<div id="sidebar-wrapper" >
						<SidBar />
					</div>

					<div id="page-content-wrapper">
						<NavbarTop toggled={this.toggled} />
						<div className="container-fluid">
							<Container >
								<div className="w-75 d-auto">
									{/* <Row>
                  <Col md={12}>
                    <h3 className="mt-3 fontsize20"> Request groups </h3>
                  </Col>
                  <Col md={4}>
                    
                    <ListGroup>

                      
                    </ListGroup>
                  </Col>

                </Row> */}

									<Row>
										<Col md={12}>
											<h3 className="mt-3 fontsize20">Group Details</h3>
										</Col>
									</Row>
									<Row>

										<Col md={12}>

											<Alert className="mb-2 w-100 p-2"
												key='1' variant={"secondary"} > {reqGroup.group_member}

												<div className="pull-right" style={{ marginTop: "-3px" }}>
													<Button variant="danger" size="sm" onClick={() => this.setModalShow()}>
														Add an Expense
                          </Button></div>
											</Alert>

										</Col>
									</Row>
									<Row>
										<Col md={12}>
											<h5 className="fontsiize16">Expenses Details</h5>

										</Col>

										<Col md={12}>
											<ListGroup>

												{group.map((usergroup, i) => (
													<ListGroup.Item className="m" style={{ cursor: 'pointer' }}
														key={i} onClick={((e) => this.handleusers(e, usergroup))}
													>
														<Row>



															<Col md="1">
																<span className="fontsiize14">
																	{this.getDateFormat(usergroup.createDate)}</span>
															</Col>
															<Col md="1">
																<div className="profilelist profileitem">
																	<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><path fill="none" stroke="#323232" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="M80.24 61.203H30.392l-6.623-38.61h65.882z" /><path fill="none" stroke="#323232" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="M30.392 61.203L18.889 73.752" /><path fill="none" stroke="#323232" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="M18.889 73.752H90" /><path fill="none" stroke="#323232" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="M23.769 22.593l-5.839-9.027" /><path fill="none" stroke="#323232" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="M17.93 13.566H10" /><circle cx="30.981" cy="80.093" r="6.341" fill="none" stroke="#323232" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" /><circle cx="76.995" cy="80.093" r="6.341" fill="none" stroke="#323232" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" />
																	</svg>
																</div>
															</Col>	<Col md="4" style={{ fontWeight: '700' }} >

																{usergroup.expname}
															</Col>	<Col md="6">
																<div className="pull-right text-right" style={{ marginTop: "-3px" }}>
																	<p className="fontsiize11 mb-0">
																		{usergroup.name + ' owes ' + usergroup.userName}
																	</p>
																	{/* <Button variant="danger" size="sm" onClick={((e) => this.handleReject(e, usergroup))}>  </Button>*/}
															C$ {usergroup.amount}
																</div>
															</Col>

														</Row>
													</ListGroup.Item>

												))}
											</ListGroup>

										</Col>
									</Row>
									<Row>
										<Col md={4}>

										</Col>
										<AddExpenses
											show={modalShow}
											onHide={() => this.setModalClose()}
											groupId={reqGroup.id}
											groupName={reqGroup.group_member}
											groupListData={reqGroup.groupListData}
										/>
										{/* <Col md={5}>
											<Button variant="primary" onClick={() => this.setModalShow()}>
												Add an expense
                    </Button>
											

										</Col>
										<Col md={3}>
											{groupusers.map((usermail, i) => (
												<div className="user" key={i}>{usermail.email}</div>
											))}
										</Col> */}
									</Row>

								</div>
							</Container>
						</div>

					</div>
				</div >

			</div >
		);
	}
}

export default Dashboard;