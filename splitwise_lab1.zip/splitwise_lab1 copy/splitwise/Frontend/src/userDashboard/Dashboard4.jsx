import React, { useRef, useState, useEffect } from 'react';
import { Container, Row, Col, Alert, Button, ListGroup, InputGroup, FormControl } from 'react-bootstrap';
import SidBar from '../components/sideBar/sideBar';
import { BASEURL, BASEURL_img } from '../constants'
import { Link } from 'react-router-dom';
import NavbarTop from '../components/navbar/NavbarTop'
import AddExpenses from './addExpenses'
import axios from 'axios';
class Dashboard extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			isOpen: true,
			user: JSON.parse(localStorage.getItem("loginUser")) || {},
			profile: null,
			group: [],
			groupusers: [],
			modalShow: false,
			groupId: '',
			reqGroup: [],
			reqgroupusers: [],
			filterValue: '',
			owedAmount: 0.00,
			owedData: [],
			oweData: [],
			// modalShow: false,
			// groupId: ''
		};
	}
	componentDidMount() {
		this.handledata();
	}

	handledata() {
		// const userDetails = JSON.parse(localStorage.getItem("userDetails"));
		axios
			.get(BASEURL + "/allOweData", {
				headers: { Authorization: JSON.parse(localStorage.getItem('Usertoken')) }
			})
			.then(response => {
				// console.log(response, 'response
				var owedData = response.data.owedData;
				var oweData = response.data.oweData;
				// 	console.log(activeData);
				// 	this.setState({ group: activeData })
				// 	if (activeData.length > 0) {
				// 		this.setState({ groupusers: activeData[0].groupListData, groupId: activeData[0].id })
				// 	}
				var owedDatas = [];
				var owedAmount = 0;
				var oweDatas = [];
				var oweAmount = 0;
				for (let od = 0; od < owedData.length; od++) {
					const element = owedData[od];
					var groupExpeData = element.groupExpeData;
					for (let i = 0; i < groupExpeData.length; i++) {
						const elementin = groupExpeData[i];
						elementin.amount = Number(elementin.amount).toFixed(2);
						elementin.name = element.name;
						owedAmount += Number(elementin.amount)
						owedDatas.push(elementin);
					}
				}
				for (let od = 0; od < oweData.length; od++) {
					const element = oweData[od];
					var groupExpeData = element.groupExpeData;
					for (let i = 0; i < groupExpeData.length; i++) {
						const elementin = groupExpeData[i];
						elementin.amount = Number(elementin.amount).toFixed(2);
						oweAmount += Number(elementin.amount)
						oweDatas.push(elementin);
					}
				}
				this.setState({ owedData: owedDatas, owedAmount: Number(owedAmount).toFixed(2) })
				this.setState({ oweData: oweDatas, oweAmount: Number(oweAmount).toFixed(2) })
				// 	if (requestData.length > 0) {
				// 		this.setState({ reqgroupusers: requestData[0].groupListData, groupId: requestData[0].id })
				// 	}
			})
			.catch(error => {
				console.log("Error fetching and parsing data", error);
				if (error == "Error: Request failed with status code 401") {
					// localStorage.removeItem("Usertoken");
					// localStorage.removeItem("loginUser");
					// this.props.history.push("/");
				}
			});
	}


	handleSettle = (e) => {
		// access to e.target here
		// console.log(e, data);
		// var owedData = this.state.owedData;
		// var oweData = this.state.oweData;
		var expArray = [];
		for (let index = 0; index < this.state.owedData.length; index++) {
			const element = this.state.owedData[index];
			expArray.push(element.id)

		}
		for (let index = 0; index < this.state.oweData.length; index++) {
			const element = this.state.oweData[index];
			expArray.push(element.id)
		}
		console.log(expArray)

		const userDetails = JSON.parse(localStorage.getItem('Usertoken'));
		const config = { headers: { Authorization: userDetails } };
		var obj = {};
		obj.expArray = expArray;
		axios.post(BASEURL + "/settleExp", obj, config)
			.then((response) => {
				// alert("The file is successfully uploaded");
				this.handledata();
				// if (response.success === true) {
				//   history.push("/dashboard");
				// }
			}).catch((error) => {
			});
	}

	toggled() {
		// console.log(state)
		const { isOpen } = this.state
		// var body = document.body;
		if (isOpen === true) {

			this.setState({
				isOpen: false
			})

			// body.classList.add("toggled");
		} else {
			this.setState({
				isOpen: true
			})
			// body.classList.remove("toggled");
		}
	}
	setModalShow = () => {
		this.setState({ modalShow: !this.state.modalShow })
	}
	searchGN = (e) => {
		console.log(e.target)
		this.setState({ filterValue: e.target.value });
	}

	// Toggle() {
	//     
	// }

	render() {
		const { group, groupusers, modalShow, groupId, reqGroup, owedAmount, owedData, oweData, oweAmount } = this.state;
		// return (
		//     <form onSubmit={this.handleSubmit}>
		//         <label>
		//             Name:
		//     <input type="text" value={this.state.firstName} onChange={this.handleChange} />
		//         </label>
		//         <input type="submit" value="Submit" />
		//     </form>
		// );
		return (


			< div className={!this.state.isOpen ? "page-wrapper" : 'page-wrapper page-side'}>
				<div id="wrapper" className={this.state.isOpen ? "toggled" : ''}>
					<div id="sidebar-wrapper" >
						<SidBar />
					</div>

					<div id="page-content-wrapper">
						<NavbarTop toggled={this.toggled} />
						<div className="container-fluid">
							<Container >
								<div className="w-75 d-auto">
									{/* <Row>
                  <Col md={12}>
                    <h3 className="mt-3 fontsize20"> Request groups </h3>
                  </Col>
                  <Col md={4}>
                    
                    <ListGroup>

                      
                    </ListGroup>
                  </Col>

                </Row> */}

									<Row>
										<Col md={6}>
											<h3 className="mt-3 fontsize20"> Dashboard </h3>
										</Col>
										<Col md={6} className="text-right">
											<h3 className="mt-3 fontsize20">
												<Button className="mr-2 " style={{ background: "#5ebea3", border: "#5ebea3" }} variant="primary" size="sm" onClick={((e) => this.handleSettle(e))}> Settle Up</Button> </h3>
										</Col>
									</Row>
									<Row className="text-center">
										<Col md={6}>
											<h5 className="fontsiize16"> You Owe </h5>
											<p className="fontsiize16 pt-0"> C$ {oweAmount}  </p>
										</Col>
										<Col md={6} >
											<h5 className="fontsiize16">You are Owed </h5>
											<p className="fontsiize16 pt-0"> C$ {owedAmount} </p>


										</Col>
										<Col md={12}>
											<Row>
												<Col md={6}>
													{oweData.length > 0 ? oweData.map((usergroup, i) => (
														<>

															<p>you owe {usergroup.name}  ${usergroup.amount}</p>

														</>
													))
														: <p className="p-3" style={{ background: '#ccc', }}> You owe nothing</p>
													}
												</Col>
												<Col md={6}>


													{owedData.length > 0 ? owedData.map((usergroup, i) => (
														<>
															<p>{usergroup.name} owes you ${usergroup.amount}</p>
														</>
													))
														: <p className="p-3" style={{ background: '#ccc', }}> You are owed nothing</p>
													}
												</Col>

											</Row>
										</Col>
									</Row>
								</div>
							</Container>
						</div>

					</div>
				</div >

			</div>
		);
	}
}

export default Dashboard;