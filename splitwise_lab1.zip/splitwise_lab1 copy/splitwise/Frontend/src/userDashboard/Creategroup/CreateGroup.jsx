import React, { useRef, useState, useEffect } from 'react';
import SidBar from '../../components/sideBar/sideBar';
import { Container, Row, Col, Form, Button } from 'react-bootstrap';
import NavbarTop from '../../components/navbar/NavbarTop'
import ReactUploadImage from '../../components/UploadImage/UploadImage'
import { useHistory } from "react-router-dom";
import { connect } from 'react-redux'
import { loginUserData, setuserdata, logUser } from '../../redux/login';
import { BASEURL } from '../../constants'

import axios from 'axios';
const CreateGroup = (props) => {
    const [items, setItems] = useState([]);
    const handleAddButtonClick = () => {
        const newItem = { name: '', email: "" };
        const newItems = [...items, newItem];
        setItems(newItems);

    };

    const removeClick = (index) => {
        let Hobbies = [...items];
        Hobbies.splice(index, 1);
        console.log(Hobbies, "Hobbies")
        // setItems(items => [...items, Hobbies]);
        setItems(Hobbies)
    }
    const onChange = (e, index) => {
        const newArr = [...items];
        newArr[index][e.target.name] = e.target.value;
        setItems(newArr);
    };
    const history = useHistory();
    const [isOpen, setisOpen] = useState(true);
    const [isMobile, setisMobile] = useState(false);
    const [errors, seterrors] = useState({});
    const [groupPhoto, setGroupImage] = useState({});

    function Toggle() { setisOpen(!isOpen) };

    const [user, setUser] = useState(props.loginDatauser);
    const [groupdata, setgroupdata] = useState({});

    const handleResize = () => {
        if ((window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth) <= 764) {
            setisMobile(true);
            setisOpen(false);
        } else {
            setisMobile(false);
            // setisOpen(false);
        }
    }
    const save = (params) => {

        const useron = localStorage.getItem("loginUser");
        const onuser = JSON.parse(useron);
        const group = { group_list: items, group_name: groupdata.group_name, avatar: '', user_id: onuser.id }
        const formData = new FormData();
        formData.append('group', JSON.stringify(group));
        formData.append('myImage', groupPhoto);
        const userDetails = JSON.parse(localStorage.getItem('Usertoken'));
        const config = { headers: { Authorization: userDetails } };
        axios.post(BASEURL + "/group", formData, config)
            .then((response) => {
                // alert("The file is successfully uploaded");
                console.log(response.data.success)
                if (response.data.success === true) {

                    history.push("/my-groups");
                }
            }).catch((error) => {
            });
    }
    useEffect(() => {
        console.log(groupdata, "groupdata")
        window.addEventListener("resize", handleResize, false);
    }, []);

    const onInputChange = (event) => {
        const { name, value } = event.target;
        console.log(name)

        setgroupdata({ [name]: value });
        validateField(name, value)
    }

    function handleUpload(value) {
        console.log(value)
        setGroupImage(value)
    }

    function validateField(fieldName, values) {
        let errors = {};
        switch (fieldName) {
            case 'name':
                if (!values.email) {
                    errors.email = 'Email address is required';
                } else if (!/\S+@\S+\.\S+/.test(values.email)) {
                    errors.email = 'Email address is invalid';
                }
                break;
            case 'name':
                if (!values.password) {
                    errors.password = 'Password is required';
                } else if (values.password.length < 6) {
                    errors.password = 'Password must be 6 or more characters';
                }
                break;
            default:
                break;

            // return errors;
        };
    }
    return (
        < div className={!isOpen ? "page-wrapper" : 'page-wrapper page-side'}>
            <div id="wrapper" className={isOpen ? "toggled" : ''}>
                <div id="sidebar-wrapper" >
                    <SidBar />
                </div>
                {console.log(errors, "ffff")}
                <div id="page-content-wrapper" >
                    <NavbarTop toggled={Toggle} />
                    <div className="container-fluid">

                        <Container>
                            <Row>
                                <Col>
                                    <h3 className="mt-3 fontsize20 mb-2"> Start new group </h3>
                                </Col>
                            </Row>

                            <div className='app-background'>
                                <Row>
                                    <Col md={3}>
                                        <div className="profile-img mb-3" style={{ backgroundImage: `url(${'./user.jpg'})` }}></div>
                                        <ReactUploadImage handleUpload={handleUpload} />

                                    </Col>
                                    <Col md={6}>
                                        <Form>

                                            <Form.Group controlId="formBasicEmail">
                                                <Form.Label>My group shall be called</Form.Label>
                                                <Form.Control type="text" placeholder="Enter group name" name="group_name" onChange={onInputChange} />

                                            </Form.Group>
                                            <Form.Group controlId="group members">
                                                <Form.Label>Group members</Form.Label>
                                                {console.log(items, "item user")}
                                                {items.map((item, index) => (
                                                    <Row className="mb-2" key={index}>
                                                        <Col xs={5}>

                                                            <Form.Control defaultValue={item.name} type="text" name="name" placeholder="Enter name" onChange={(event) => onChange(event, index)} />
                                                        </Col>
                                                        <Col xs={5}>
                                                            <Form.Control defaultValue={item.email} type="email" name="email" placeholder="Enter email" onChange={(event) => onChange(event, index)} />

                                                        </Col>
                                                        <Col xs={1}>
                                                            <p style={{ cursor: "pointer", color: '#009273', fontWeight: '500' }} onClick={() => removeClick((index))} >X </p>
                                                        </Col>

                                                    </Row>
                                                ))}


                                            </Form.Group>
                                            <p style={{ cursor: "pointer", color: '#009273', fontWeight: '500' }} onClick={() => handleAddButtonClick()} >+ Add a person </p>
                                            <Button variant="warning" onClick={save} class="float-right">save</Button>
                                        </Form>
                                    </Col> <div>

                                    </div>
                                </Row>
                            </div>
                            <Row>
                            </Row>
                        </Container>
                    </div>

                </div>
            </div >

        </div>
    );
};



export default CreateGroup;