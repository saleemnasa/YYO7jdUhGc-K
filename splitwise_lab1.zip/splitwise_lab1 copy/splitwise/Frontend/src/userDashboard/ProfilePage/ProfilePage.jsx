
import './login.css';
import { Container, Row, Col } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { connect } from 'react-redux';
import { loginUserData, setuserdata, logUser } from '../../redux/login';


const ProfilePage = (props) => {

  const [user, setuser] = useState(JSON.parse(localStorage.getItem("loginUser")) || {});

  useEffect(() => {
    console.log(props.loginDatauser, "props.loginDatauser")
    if (props.loginDatauser) {
      history.push("/");
    }

  });

  return (
    <div className="section  elment-center" >
      <Container>
        <Row >
          <Col md={12} className="pt-5 pb-3">
            <div className="registration-block text-center mb-4">
              <h3>Your account</h3>

            </div>

          </Col>

          <Col md={12} className="pt-5 pb-3">

            <div className="login-banner d-flex justify-content-center bd-highlight mb-3">
              hhh
            </div>
          </Col>

        </Row>

      </Container>

    </div>
  );
};
export default connect(
  (state) => {
    return {
      loginDatauser: state.login.loginData
    }
  },
  {
    loginUserData,
    setuserdata,
    logUser
  }
)(ProfilePage);