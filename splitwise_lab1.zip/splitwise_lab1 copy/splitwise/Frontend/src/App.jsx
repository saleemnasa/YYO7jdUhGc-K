import React from 'react';
import './App.css';
import { BrowserRouter, Switch } from 'react-router-dom';
import PrivateRoute from './components/PrivateRoute';
import PublicRoute from './components/PublicRoute';
import Login from './pages/loginPage/login'
import Signup from './pages/signupPage/signup'
import CreateGroup from './userDashboard/Creategroup/CreateGroup'
import Dashboard1 from './userDashboard/Dashboard1'
import Dashboard from './userDashboard/Dashboard4'
import RecentActivity from './userDashboard/RecentActivity'
import MyGroupChild from './userDashboard/MyGroupChild'

import Home from './pages/Home/Home';
import EditProfile from './userDashboard/EditProfile/EditProfile';
const App = (props) => {
  return (
    <>
      <div className="App">
        <>
          <BrowserRouter>
            <Switch>
              <PublicRoute restricted={false} component={Login} path="/login" exact />
              <PublicRoute restricted={false} component={Signup} path="/signup" exact />
              <PublicRoute restricted={true} component={Home} path="/" exact />
              <PrivateRoute component={Dashboard} path="/dashboard" exact />
              <PrivateRoute component={EditProfile} path="/profile" exact />
              <PrivateRoute component={CreateGroup} path="/creategroup" exact />
              <PrivateRoute component={Dashboard1} path="/my-groups" exact />
              <PrivateRoute component={Dashboard} path="/dashboard" exact />
              <PrivateRoute component={RecentActivity} path="/recent-activity" />
              <PrivateRoute path='/my-groups/:groupId' component={MyGroupChild} />

            </Switch>
          </BrowserRouter>
        </>
      </div>
    </>
  );
}

export default App;
