export const getLocalStorageItem: any = (key: any) => {
  if (typeof localStorage !== 'undefined') {
    if (localStorage.getItem(key) !== "" && localStorage.getItem(key) !== null) {
      return (localStorage.getItem(key));
    }
    return null;
  }
  return null;
}

export const DOMAIN = (typeof window !== 'undefined') ? window.location.origin + "" : "";
const assets = "/assets";

// BASE_API_GOOGLE_URL: 'http://localhost:4001',


export const BASEURL = 'http://localhost:3000/v1';
export const BASEURL_img = 'http://localhost:3000/';

export const RESTAPI_HEADERS_JSON = { "Content-Type": "application/json" };
export const RESTAPI_HEADERS_JSON_AUTHORIZATION = { "Content-Type": "application/json", "Authorization": "" };
export const NEWBUSINESSOFFTHEWEEK = BASEURL + "/search?type=storefronts&sortCreateAt=-1&limit=10";



export const logo = DOMAIN + "/images/logo.png";
export const user = DOMAIN + "/images/user.jpg";
export const logo2 = DOMAIN + "/logo.svg";



