import fetch from 'isomorphic-unfetch';
import { BASEURL } from '../constants'
const apiClient = {
  Urls: {
    BASEURL,

  },


  make: function (url: string, method: string, params: object) {
    if (method == 'POST') {
      return fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: JSON.stringify(params),
      })
        .then((response: any) => response.json())
        .catch((e: any) => e);
    }
    if (method == 'GET') {
      return fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
      })
        .then((response: any) => response.json())
        .catch((e: any) => e);
    }
  },

  post: function (url: string, params?: any) {
    return this.make(url, 'POST', params);
  },

  get: function (url: string, params?: any) {
    return this.make(url, 'GET', params);
  },
};

export default apiClient;
