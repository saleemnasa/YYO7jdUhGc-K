import apiClient from "../utils/apiClient";

import Swal from 'sweetalert2'
import { useHistory } from "react-router-dom";

const TEST = 'redux/home/TEST';
const ERROR = "redux/home/ERROR";
const LOGIN_SUCCESS = 'redux/home/LOGIN_SUCCESS';
const LOGIN_START = 'redux/home/LOGIN_START';
const SET_USER_DATA = 'modules/home/SET_USER_DATA';
const SET_USER_LOGIN_DATA = 'modules/home/SET_USER_LOGIN_DATA';

const SET_USER_SINUP_START = 'modules/home/SET_USER_SINUP_START';
const SET_USER_SINUP__SUCCESS = 'modules/home/SET_USER_SINUP__SUCCESS';

const InitialState = {
    test: '',
    error: {
        title: '',
        message: '',
    },
    whatData: [],
    whereData: [],
    userdata: {},
    whereText: "",
    categories: [],
    subcategories: [],
    loginData: JSON.parse(localStorage.getItem("loginUser")) || {}
}
const displayError = (title, message, loading = 'loading') => ({
    type: ERROR,
    title,
    message,
    loading,
});
export const setuserdata = (userdata) => (console.log(userdata), {
    type: SET_USER_DATA,
    userdata,
});
export const loginUserData = () => ({
    type: SET_USER_LOGIN_DATA
});


export const logUser = () => async (dispatch, getState) => {

    const state = getState();
    const { userdata } = state.login;
    let url = apiClient.Urls.BASEURL + `/users/login`;
    dispatch({
        type: LOGIN_START,
    });
    try {
        const response = await apiClient.post(url, userdata);

        if (response.success === false) {
            Swal.fire({
                icon: 'error',
                title: response.error.toUpperCase(),
                timer: 3000
            })

        }
        if (response.success === true) {
            localStorage.setItem('loginUser', JSON.stringify(response.user));
            localStorage.setItem('Usertoken', JSON.stringify(response.token));

            Swal.fire({
                position: 'top-end',
                icon: 'success',
                title: 'You are successfully logged in',
                showConfirmButton: false,
                timer: 1500
            })
            dispatch({
                type: LOGIN_SUCCESS,
                whatData: response,
            })
        }


    } catch (e) {
        dispatch(displayError('EXCEPTION', e.message));
    }
};
export const sinupUser = () => async (dispatch, getState) => {
    const state = getState();
    const { userdata } = state.login;
    let url = apiClient.Urls.BASEURL + `/users`;
    console.log(url)
    dispatch({
        type: SET_USER_SINUP_START,
    });
    try {
        const response = await apiClient.post(url, userdata);

        if (response.success === false) {
            Swal.fire({
                icon: 'error',
                title: response.error.toUpperCase(),
                timer: 3000
            })
        }
        if (response.success === true) {
            localStorage.setItem('loginUser', JSON.stringify(response.user));
            localStorage.setItem('Usertoken', JSON.stringify(response.token));
            Swal.fire({
                position: 'top-end',
                icon: 'success',
                title: 'You are successfully logged in',
                showConfirmButton: false,
                timer: 1500
            })
            dispatch({
                type: SET_USER_SINUP__SUCCESS,
                user: response.user,
            })
        }


    } catch (e) {
        dispatch(displayError('EXCEPTION', e.message));
    }
};
const foodReducer = (state = InitialState, action) => {


    switch (action.type) {

        case LOGIN_START: {
            return {
                ...state,
            };
        }

        case SET_USER_LOGIN_DATA: {
            const useronData = localStorage.getItem("loginUser") || {};
            return {
                ...state,
                loginData: useronData,
            };
        }

        case LOGIN_SUCCESS: {
            console.log('action.whatData');
            console.log(action.whatData);

            return {

                ...state,
                loginData: action.whatData,
            }
        };

        case SET_USER_SINUP_START: {
            return {
                ...state,
            };
        }

        case SET_USER_SINUP__SUCCESS: {
            console.log('action.whatData');
            console.log(action.user);
            return {
                ...state,
                loginData: action.user,
            }
        };

        case SET_USER_DATA: {
            return {
                ...state,
                userdata: action.userdata
            }
        };
        default:
            return state;
    }
}

export default foodReducer
