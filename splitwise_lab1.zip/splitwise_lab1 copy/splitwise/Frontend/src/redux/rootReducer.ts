import login from './login';
export default {
  login: login
}