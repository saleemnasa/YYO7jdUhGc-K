import { combineReducers, applyMiddleware, createStore } from 'redux';
import thunk from 'redux-thunk';
import rootReducer from './rootReducer';

const reducer = combineReducers(rootReducer);

const store = createStore(
  reducer,
  undefined,
  applyMiddleware(thunk)
);

export default store;

// const enableReduxDevTools = window.__REDUX_DEVTOOLS_EXTENSION__?.();

// export function createReduxStore() {
//   const store = createStore(foodReducer, enableReduxDevTools);
//   return store;
// }